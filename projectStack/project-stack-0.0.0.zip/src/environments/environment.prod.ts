export const environment = {
  production: true,
  encryptKey: "Gosh",
  baseApi:"https://oao58z9vpe.execute-api.us-east-1.amazonaws.com/latest",
  disableEncryption:false
};

