import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'custom-button',
  templateUrl: './custom-button.component.html',
  styleUrls: ['./custom-button.component.scss']
})
export class CustomButtonComponent implements OnInit {
  @Output('clickEvent') click = new EventEmitter();
  @Input() loading;
  @Input() passedClass;
  @Input() color;
  @Input() styles;
  @Input() disabled;
  @Input() rounded;
  @Input() stroked;
  @Input() long;
  @Input() thin;
  constructor() { }

  ngOnInit() {
  }

  get classes(){
    return {
      ...(this.passedClass?this.passedClass:{}),
      'strokedButton':this.stroked,
      'roundedButton':this.rounded,
      'longButton':this.long,
      'thinButton':this.thin,
      'color-white':!this.stroked,
      'white-button':!this.stroked
    }
  }

}
