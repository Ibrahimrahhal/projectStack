import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-requests',
  templateUrl: './join-requests.component.html',
  styleUrls: ['./join-requests.component.scss']
})
export class JoinRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
