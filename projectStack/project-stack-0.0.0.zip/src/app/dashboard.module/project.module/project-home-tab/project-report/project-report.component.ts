import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-report',
  templateUrl: './project-report.component.html',
  styleUrls: ['./project-report.component.scss']
})
export class ProjectReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
