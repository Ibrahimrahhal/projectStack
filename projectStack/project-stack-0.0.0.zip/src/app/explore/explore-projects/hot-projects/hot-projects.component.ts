import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-projects',
  templateUrl: './hot-projects.component.html',
  styleUrls: ['./hot-projects.component.scss']
})
export class HotProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
