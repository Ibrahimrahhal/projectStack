export default [{
  "ID": "1",
  "DESC": "Mechanical Engineering"
}, {
  "ID": "2",
  "DESC": "Computer Engineering"
}, {
  "ID": "3",
  "DESC": "Civil Engineering"
}, {
  "ID": "4",
  "DESC": "chemical engineering"
}, {
  "ID": "5",
  "DESC": "architectural engineering"
}, {
  "ID": "6",
  "DESC": "electrical engineering"
}, {
  "ID": "7",
  "DESC": "Medicine "
}, {
  "ID": "8",
  "DESC": "Information Technology "
}, {
  "ID": "9",
  "DESC": "Science "
}, {
  "ID": "10",
  "DESC": "Computer Science"
}, {
  "ID": "11",
  "DESC": "Educational Science"
}, {
  "ID": "12",
  "DESC": "Physical education"
}, {
  "ID": "13",
  "DESC": "Art & Design"
}, {
  "ID": "14",
  "DESC": "Business Studies"
}, {
  "ID": "15",
  "DESC": "Engineering"
}, {
  "ID": "16",
  "DESC": "Financial Studies"
}];
