export default [{
  "ID": "2",
  "DESC": "Science"
}, {
  "ID": "3",
  "DESC": "Volunteer Work"
}, {
  "ID": "4",
  "DESC": "Blogging"
}, {
  "ID": "5",
  "DESC": "Business"
}, {
  "ID": "6",
  "DESC": "Start up"
}, {
  "ID": "8",
  "DESC": "Reading"
}, {
  "ID": "9",
  "DESC": "Machine Learning"
}, {
  "ID": "10",
  "DESC": "Programming"
}, {
  "ID": "11",
  "DESC": "Video Games"
}, {
  "ID": "12",
  "DESC": "Graphic Design"
}, {
  "ID": "13",
  "DESC": "User Experience "
}, {
  "ID": "1",
  "DESC": "Technology"
}]
