export default [{
  ID:'1',
  DESC:'Graduation'
},{
  ID:'2',
  DESC:'Entrepreneural'
},{
  ID:'3',
  DESC:'Volunteering'
},{
  ID:'4',
  DESC:'Research'
}];
