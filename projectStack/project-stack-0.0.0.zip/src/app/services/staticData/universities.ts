export default [{
  "ID": "1",
  "DESC": "University Of Jordan"
}, {
  "ID": "2",
  "DESC": "german jordanian university"
}, {
  "ID": "3",
  "DESC": "princess sumaya university for technology"
}, {
  "ID": "4",
  "DESC": "Jordan University of Science and Technology"
}, {
  "ID": "5",
  "DESC": "petra university"
}, {
  "ID": "6",
  "DESC": "The Hashemite University"
}, {
  "ID": "7",
  "DESC": "Philadelphia University"
}, {
  "ID": "8",
  "DESC": "Middle East University"
}, {
  "ID": "9",
  "DESC": "Applied Science Private University"
}]
