export default [{
  "ID": "2",
  "DESC": "MatLab "
}, {
  "ID": "3",
  "DESC": "aurduino"
}, {
  "ID": "4",
  "DESC": "creo"
}, {
  "ID": "5",
  "DESC": "autocade"
}, {
  "ID": "6",
  "DESC": "excel"
}, {
  "ID": "7",
  "DESC": "GLPK"
}, {
  "ID": "8",
  "DESC": "GOBLIN"
}, {
  "ID": "9",
  "DESC": "openforecast"
}, {
  "ID": "10",
  "DESC": "Empathy "
}, {
  "ID": "11",
  "DESC": "Selflessness"
}, {
  "ID": "12",
  "DESC": "Agility"
}, {
  "ID": "13",
  "DESC": "Listening"
}, {
  "ID": "14",
  "DESC": "Humility"
}, {
  "ID": "15",
  "DESC": "Cultural intelligence"
}, {
  "ID": "16",
  "DESC": "Authenticity"
}, {
  "ID": "17",
  "DESC": "Versatility"
}, {
  "ID": "18",
  "DESC": "Generosity"
}, {
  "ID": "19",
  "DESC": "Trust"
}, {
  "ID": "20",
  "DESC": "Friendliness"
}, {
  "ID": "21",
  "DESC": "Goal setting"
}, {
  "ID": "22",
  "DESC": "Prioritizing"
}, {
  "ID": "23",
  "DESC": "Self-starter"
}, {
  "ID": "24",
  "DESC": "Planning"
}, {
  "ID": "25",
  "DESC": "Decision making"
}, {
  "ID": "26",
  "DESC": "Focus"
}, {
  "ID": "27",
  "DESC": "Delegation"
}, {
  "ID": "28",
  "DESC": "Stress management"
}, {
  "ID": "29",
  "DESC": "Coping"
}, {
  "ID": "30",
  "DESC": "Organization"
}, {
  "ID": "31",
  "DESC": "Empathy"
}, {
  "ID": "32",
  "DESC": "Humor"
}, {
  "ID": "33",
  "DESC": "Mentoring"
}, {
  "ID": "34",
  "DESC": "Networking"
}, {
  "ID": "35",
  "DESC": "Sensitivity"
}, {
  "ID": "36",
  "DESC": "Patience"
}, {
  "ID": "37",
  "DESC": "Tolerance"
}, {
  "ID": "38",
  "DESC": "Public speaking"
}, {
  "ID": "39",
  "DESC": "Positive reinforcement"
}, {
  "ID": "40",
  "DESC": "Diplomacy"
}, {
  "ID": "41",
  "DESC": "Integrity "
}, {
  "ID": "42",
  "DESC": "Responsibility"
}, {
  "ID": "43",
  "DESC": "Discipline"
}, {
  "ID": "44",
  "DESC": "Initiative"
}, {
  "ID": "45",
  "DESC": "Dependability"
}, {
  "ID": "46",
  "DESC": "Commitment"
}, {
  "ID": "47",
  "DESC": "Self-motivated"
}, {
  "ID": "48",
  "DESC": "Professionalism"
}, {
  "ID": "49",
  "DESC": "Teamwork"
}, {
  "ID": "50",
  "DESC": "Time-management"
}, {
  "ID": "51",
  "DESC": "Divergent thinking "
}, {
  "ID": "52",
  "DESC": "Inspiration"
}, {
  "ID": "53",
  "DESC": "Imagination"
}, {
  "ID": "54",
  "DESC": "Reframing"
}, {
  "ID": "55",
  "DESC": "Mind mapping"
}, {
  "ID": "56",
  "DESC": "Insight"
}, {
  "ID": "57",
  "DESC": "Innovation"
}, {
  "ID": "58",
  "DESC": "Experimenting"
}, {
  "ID": "59",
  "DESC": "Questioning"
}, {
  "ID": "60",
  "DESC": "Design"
}, {
  "ID": "61",
  "DESC": "Analysis"
}, {
  "ID": "62",
  "DESC": "Lateral thinking"
}, {
  "ID": "63",
  "DESC": "Logical reasoning"
}, {
  "ID": "64",
  "DESC": "Initiative"
}, {
  "ID": "65",
  "DESC": "Persistence"
}, {
  "ID": "66",
  "DESC": "Observation"
}, {
  "ID": "67",
  "DESC": "Persuasion"
}, {
  "ID": "68",
  "DESC": "Negotiation"
}, {
  "ID": "69",
  "DESC": "Brainstorming"
}, {
  "ID": "70",
  "DESC": "Decision making"
}, {
  "ID": "71",
  "DESC": "Curiosity "
}, {
  "ID": "72",
  "DESC": "Self-management"
}, {
  "ID": "73",
  "DESC": "Decision-making"
}, {
  "ID": "74",
  "DESC": "Calmness"
}, {
  "ID": "75",
  "DESC": "Optimism"
}, {
  "ID": "76",
  "DESC": "Open-mindedness"
}, {
  "ID": "77",
  "DESC": "Analysis"
}, {
  "ID": "78",
  "DESC": "Self-confidence"
}, {
  "ID": "79",
  "DESC": "Organization"
}, {
  "ID": "80",
  "DESC": "Self-motivation"
}, {
  "ID": "81",
  "DESC": "Conflict management "
}, {
  "ID": "82",
  "DESC": "Delegation"
}, {
  "ID": "83",
  "DESC": "Listening"
}, {
  "ID": "84",
  "DESC": "Active listening"
}, {
  "ID": "85",
  "DESC": "Collaboration"
}, {
  "ID": "86",
  "DESC": "Cooperation"
}, {
  "ID": "87",
  "DESC": "Coordination"
}, {
  "ID": "88",
  "DESC": "Idea exchange"
}, {
  "ID": "89",
  "DESC": "Mediation"
}, {
  "ID": "90",
  "DESC": "Negotiating"
}, {
  "ID": "91",
  "DESC": "ement. Some examples include:"
}, {
  "ID": "92",
  "DESC": "Clarity"
}, {
  "ID": "93",
  "DESC": "Confidence"
}, {
  "ID": "94",
  "DESC": "Respect"
}, {
  "ID": "95",
  "DESC": "Empathy"
}, {
  "ID": "96",
  "DESC": "Listening"
}, {
  "ID": "97",
  "DESC": "Verbal communication"
}, {
  "ID": "98",
  "DESC": "Non-verbal communication"
}, {
  "ID": "99",
  "DESC": "Written communication"
}, {
  "ID": "100",
  "DESC": "Constructive feedback"
}, {
  "ID": "101",
  "DESC": "Technical writning"
}, {
  "ID": "102",
  "DESC": "Project management "
}, {
  "ID": "103",
  "DESC": "Programming "
}, {
  "ID": "104",
  "DESC": "CRM "
}, {
  "ID": "105",
  "DESC": "CAD"
}, {
  "ID": "106",
  "DESC": "FEA "
}, {
  "ID": "107",
  "DESC": "creo "
}, {
  "ID": "108",
  "DESC": "autocad "
}, {
  "ID": "109",
  "DESC": "microsoft office "
}, {
  "ID": "110",
  "DESC": "ansys "
}, {
  "ID": "111",
  "DESC": "solidworks"
}, {
  "ID": "112",
  "DESC": "Revit"
}, {
  "ID": "113",
  "DESC": "fusion 360"
}, {
  "ID": "114",
  "DESC": "ploysun"
}, {
  "ID": "115",
  "DESC": "SAM"
}, {
  "ID": "116",
  "DESC": "SketchUp"
}, {
  "ID": "117",
  "DESC": "control systems"
}, {
  "ID": "118",
  "DESC": "operation research"
}, {
  "ID": "119",
  "DESC": "supply chain"
}, {
  "ID": "120",
  "DESC": "logistics"
}, {
  "ID": "121",
  "DESC": "manufacturing"
}, {
  "ID": "122",
  "DESC": "operation management"
}, {
  "ID": "123",
  "DESC": "human factors"
}, {
  "ID": "124",
  "DESC": "quality control"
}, {
  "ID": "125",
  "DESC": "quality management"
}, {
  "ID": "126",
  "DESC": "industrial design"
}, {
  "ID": "127",
  "DESC": "consulting "
}, {
  "ID": "128",
  "DESC": "pure statistics"
}, {
  "ID": "129",
  "DESC": "Renewable energy "
}, {
  "ID": "130",
  "DESC": "power plants "
}, {
  "ID": "131",
  "DESC": "HVAC "
}, {
  "ID": "132",
  "DESC": "manufacturing"
}, {
  "ID": "133",
  "DESC": "transportation systems "
}, {
  "ID": "134",
  "DESC": "system dynamics and control"
}, {
  "ID": "135",
  "DESC": "ground vehicle systems"
}, {
  "ID": "136",
  "DESC": "Mechanical Design "
}, {
  "ID": "137",
  "DESC": "Material science"
}, {
  "ID": "138",
  "DESC": "thermal "
}, {
  "ID": "139",
  "DESC": "applied "
}, {
  "ID": "140",
  "DESC": "3D printing "
}, {
  "ID": "141",
  "DESC": "Matblab"
}, {
  "ID": "142",
  "DESC": "c++"
}, {
  "ID": "143",
  "DESC": "java"
}, {
  "ID": "144",
  "DESC": "Python"
}, {
  "ID": "145",
  "DESC": "protues"
}, {
  "ID": "146",
  "DESC": "Javascript"
}, {
  "ID": "147",
  "DESC": "pycharm"
}, {
  "ID": "148",
  "DESC": "Communications "
}, {
  "ID": "149",
  "DESC": "Power systems "
}, {
  "ID": "150",
  "DESC": "Electronics "
}, {
  "ID": "151",
  "DESC": "Renewable energy "
}, {
  "ID": "152",
  "DESC": "CCNA as a first level "
}, {
  "ID": "153",
  "DESC": "Polymerization"
}, {
  "ID": "154",
  "DESC": "Petro refining"
}, {
  "ID": "155",
  "DESC": "Water desalination"
}, {
  "ID": "156",
  "DESC": "Wastewater treatment"
}, {
  "ID": "157",
  "DESC": "Air pollution"
}, {
  "ID": "158",
  "DESC": "Corrosion"
}, {
  "ID": "159",
  "DESC": "NEP piploma"
}, {
  "ID": "160",
  "DESC": "NEBOSH IGC"
}, {
  "ID": "161",
  "DESC": "MATLAB"
}, {
  "ID": "162",
  "DESC": "Aspin HYSYS"
}, {
  "ID": "163",
  "DESC": "Microsoft visio"
}, {
  "ID": "164",
  "DESC": "Polymath"
}, {
  "ID": "165",
  "DESC": "Coco simulation"
}, {
  "ID": "166",
  "DESC": "Chemicad"
}, {
  "ID": "167",
  "DESC": "Excel"
}, {
  "ID": "168",
  "DESC": "AutoCAD"
}, {
  "ID": "169",
  "DESC": "Etabs"
}, {
  "ID": "170",
  "DESC": "Sap2000"
}, {
  "ID": "171",
  "DESC": "Revit"
}, {
  "ID": "172",
  "DESC": "safe"
}, {
  "ID": "173",
  "DESC": "Primavera"
}, {
  "ID": "174",
  "DESC": "SewerCAD"
}, {
  "ID": "175",
  "DESC": "Structure"
}, {
  "ID": "176",
  "DESC": "water"
}, {
  "ID": "177",
  "DESC": "environment"
}, {
  "ID": "178",
  "DESC": "surveying"
}, {
  "ID": "179",
  "DESC": "managment"
}, {
  "ID": "180",
  "DESC": "3d modelling"
}, {
  "ID": "181",
  "DESC": "Sketching"
}, {
  "ID": "182",
  "DESC": "Presenting"
}, {
  "ID": "183",
  "DESC": "Data analysis"
}, {
  "ID": "184",
  "DESC": "Management & planning"
}, {
  "ID": "185",
  "DESC": "visual presentation"
}, {
  "ID": "186",
  "DESC": "autocad"
}, {
  "ID": "187",
  "DESC": "Revit"
}, {
  "ID": "188",
  "DESC": "3dsmax"
}, {
  "ID": "189",
  "DESC": "Sketchup"
}, {
  "ID": "190",
  "DESC": "Lumion"
}, {
  "ID": "191",
  "DESC": "Rhino"
}, {
  "ID": "192",
  "DESC": "photoshop"
}, {
  "ID": "193",
  "DESC": "Environmental planning"
}, {
  "ID": "194",
  "DESC": "Urban planning"
}, {
  "ID": "195",
  "DESC": "Sustainable development"
}, {
  "ID": "196",
  "DESC": "Green & ecologic architecture"
}, {
  "ID": "197",
  "DESC": "Design & psychology"
}, {
  "ID": "198",
  "DESC": "Transportation & connectivity"
}, {
  "ID": "199",
  "DESC": "Landscape architecture"
}, {
  "ID": "200",
  "DESC": "Acoustics & lighting"
}, {
  "ID": "201",
  "DESC": "Anthropology in architecture"
}, {
  "ID": "202",
  "DESC": "urban design"
}, {
  "ID": "203",
  "DESC": "Nodejs"
}, {
  "ID": "204",
  "DESC": "Angular 2"
}, {
  "ID": "205",
  "DESC": "Angular JS"
}, {
  "ID": "206",
  "DESC": "React JS"
}, {
  "ID": "207",
  "DESC": "Web Development"
}, {
  "ID": "208",
  "DESC": "React JS"
}, {
  "ID": "209",
  "DESC": "React Native"
}, {
  "ID": "210",
  "DESC": "Flutter"
}, {
  "ID": "211",
  "DESC": "JSP"
}, {
  "ID": "212",
  "DESC": "GraphQL"
}, {
  "ID": "213",
  "DESC": "Cloud Computing"
}, {
  "ID": "214",
  "DESC": "Amazon Web Servers"
}, {
  "ID": "215",
  "DESC": "Azure"
}, {
  "ID": "216",
  "DESC": "Google Cloud"
}, {
  "ID": "217",
  "DESC": "Vue JS"
}, {
  "ID": "218",
  "DESC": "Design Patters"
}, {
  "ID": "219",
  "DESC": "Softwate. Architecture"
}, {
  "ID": "220",
  "DESC": "Adobe Photoshop"
}, {
  "ID": "221",
  "DESC": "Adobe Illustrator"
}, {
  "ID": "222",
  "DESC": "Adobe XD"
}]
