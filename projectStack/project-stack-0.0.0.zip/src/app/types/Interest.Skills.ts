export interface Interest{
  ID:string;
  DESC:string;
}


export interface Skill{
  ID:string;
  DESC:string;
}
