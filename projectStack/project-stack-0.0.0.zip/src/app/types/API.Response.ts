export interface APIResponse{
  data:String;
}
export interface EmptyResponse{
  
}