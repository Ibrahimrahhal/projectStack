export interface University{
  DESC:string;
  ID:string;
}

export interface Department{
  DESC:string;
  ID:string;
}
