export interface ProjectCategory{
  DESC:string;
  ID:string;
}
