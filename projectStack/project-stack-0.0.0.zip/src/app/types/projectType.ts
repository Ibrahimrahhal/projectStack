export interface ProjectType{
  DESC:string;
  ID:string;
}
